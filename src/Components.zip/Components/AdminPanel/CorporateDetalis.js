import React, { useEffect, useState } from "react";
import "../../Css/AdminGeneralProfile.css";
import AdminHeader from "./AdminHeader";
import {
  get_quote,
  server_post_data,
} from "../../ServiceConnection/serviceconnection";

function CorporateDetalis() {
  const [corporateData, setCorporateData] = useState([]);
  const [subscriberData, setsubscriberData] = useState([]);
  const [contactData, setcontactData] = useState([]);
  const [showLoader, setShowLoader] = useState(false);
  const [activeTab, setActiveTab] = useState("corporate");

  const master_data_get = async () => {
    const fd = new FormData();
    setShowLoader(true);
    await server_post_data(get_quote, fd)
      .then((Response) => {
        setShowLoader(false);
        if (Response.data.error) {
          alert(Response.data.message);
        } else {
          setCorporateData(Response.data.message.data_ethi_feeds_master);
          setsubscriberData(Response.data.message.web_subscribeEmaildata);
          setcontactData(Response.data.message.web_contactFormdata);
        }
      })
      .catch((error) => {
        setShowLoader(false);
      });
  };

  useEffect(() => {
    master_data_get();
  }, []);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="container-xl create_diet_plan general_profile">
      <div className={showLoader ? "loading" : ""}></div>
      <div>
        <AdminHeader />
      </div>

      <div>
        <div className="general_profile_uplaod_wrapper">
          <div className="uplaod_container">
            <div className="tableTabs">
              <h5
                className={`my-4 ${
                  activeTab === "corporate" ? "selectedTabA" : ""
                }`}
                onClick={() => handleTabClick("corporate")}
              >
                Corporate Details
              </h5>
              <h5
                className={`my-4 ${
                  activeTab === "subscribers" ? "selectedTabA" : ""
                }`}
                onClick={() => handleTabClick("subscribers")}
              >
                Subscribers
              </h5>
              <h5
                className={`my-4 ${
                  activeTab === "contacts" ? "selectedTabA" : ""
                }`}
                onClick={() => handleTabClick("contacts")}
              >
                Contact Details
              </h5>
            </div>
            <div className="upload_list_wrapper">
              {activeTab === "corporate" && (
                <div className="leave_list_table table-responsive rounded">
                  <table className="table rounded text-center">
                    <thead className="thead_bg rounded">
                      <tr className="rounded ">
                        <th scope="col">S.No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Company</th>
                        <th scope="col">Email Id</th>
                        <th scope="col">Phone No.</th>
                        <th scope="col">No. of Employees</th>
                      </tr>
                    </thead>
                    <tbody className="rounded-bottom">
                      {corporateData.map((data, index) => (
                        <tr key={index}>
                          <td scope="row">{index + 1}</td>
                          <td>{data.customer_name}</td>
                          <td className="tdBtnApprove">{data.company_name}</td>
                          <td>{data.work_email_id}</td>
                          <td>{data.mobile_no}</td>
                          <td>{data.no_of_employee}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {activeTab === "subscribers" && (
                <div className="leave_list_table table-responsive rounded">
                  <table className="table rounded text-center">
                    <thead className="thead_bg rounded">
                      <tr className="rounded ">
                        <th scope="col">S.No.</th>
                        <th scope="col">Email Id</th>
                      </tr>
                    </thead>
                    <tbody className="rounded-bottom">
                      {subscriberData.map((data, index) => (
                        <tr key={index}>
                          <td scope="row">{index + 1}</td>
                          <td>{data.email}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {activeTab === "contacts" && (
                <div className="leave_list_table table-responsive rounded">
                  <table className="table rounded text-center">
                    <thead className="thead_bg rounded">
                      <tr className="rounded ">
                        <th scope="col">S.No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email Id</th>
                        <th scope="col">Phone No.</th>
                      </tr>
                    </thead>
                    <tbody className="rounded-bottom">
                      {contactData.map((data, index) => (
                        <tr key={index}>
                          <td scope="row">{index + 1}</td>
                          <td>{data.fullName}</td>
                          <td>{data.email}</td>
                          <td>{data.phoneNo}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CorporateDetalis;

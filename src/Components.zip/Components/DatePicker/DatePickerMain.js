import FullCalendarApp from "./FullCalendar";
import Canlender3 from "./Calender";

export default function App() {
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      {/* <FullCalendarApp /> */}
      <Canlender3 />
    </div>
  );
}
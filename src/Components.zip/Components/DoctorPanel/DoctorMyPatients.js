import React, { useState, useEffect } from "react";
import DoctorHeader from "./DoctorHeader";
import "../../Css/MyPatients.css";
import { Link } from "react-router-dom";
import ProfileImgSample from "../../Assests/images/profile_sample.jpg";
import EmailSvg from "../../Assests//images/email.svg";
import goalicon from "../../Assests/images/goal.png";
import {
  my_patients_full_details_doctor,
  my_patients_data_single,
  server_post_data,
  APL_LINK,
} from "../../ServiceConnection/serviceconnection.js";
import { retrieveData } from "../../LocalConnection/LocalConnection.js";
import telephone from "../../Assests/images/telephone_black.svg";
import SearchIcon from "../../Assests/images/search_icon.svg";
import VideoCall from "../../Assests/images/video_call_svg.svg";

export default function DoctorMyPatients() {
  const [retriveDoctorId, setRetriveDoctorId] = useState("");
  const [showLoader, setShowLoader] = useState(false);
  const [upcomingAppointImage, setUpcomingAppointImage] = useState();
  const [patients, setPatients] = useState([]);
  const [patientsold, setPatientsold] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState();
  const [customergoal, setcustomergoal] = useState([]);
  const [showProfile, setshowProfile] = useState(false);
  const [showdietplan, setshowdietplan] = useState(false);
  /*shubham jain codeing */

  const master_data_get = async (retrievedDoctorId) => {
    setShowLoader(true);
    const fd = new FormData();
    fd.append("doctor_id", retrievedDoctorId);
    await server_post_data(my_patients_full_details_doctor, fd)
      .then((Response) => {
        if (Response.data.error) {
          // console.log(Response.data.message.item.entry_date) 
          alert(Response.data.message);
        } else {     
          
          setPatients(Response.data.message.data_customer_data);
          setPatientsold(Response.data.message.data_customer_data_past);
          setUpcomingAppointImage(
            APL_LINK + Response.data.message.data_user_image
          );
          
        }
        setShowLoader(false);
      })
      .catch((error) => {
        setShowLoader(false);
      });
  };

  const call_single_data = async (customer_id, index) => {
    setShowLoader(true);
    const fd = new FormData();
    fd.append("customer_id", customer_id);
    fd.append("doctor_id", retriveDoctorId);
    fd.append("extra_flag", "1");
    await server_post_data(my_patients_data_single, fd)
      .then((Response) => {
        if (Response.data.error) {
          alert(Response.data.message);
        } else {
          setcustomergoal(Response.data.message.customers_goals);
          handleShowProfile(index);
        }
        setShowLoader(false);
      })
      .catch((error) => {
        setShowLoader(false);
      });
  };
  useEffect(() => {
    const retrievedDoctorId = retrieveData("doctor_id");
    setRetriveDoctorId(retrievedDoctorId);
    master_data_get(retrievedDoctorId);
  }, []);
  /*shubham jain codeing */

  // Function to handle the patient click
  const handlePatientClick = (patient, index, click_by) => {
    setshowdietplan(click_by);
    call_single_data(patient._id, index);
    setSelectedPatient({ ...patient, keyIndex: index });
  };

  // OLd

  // Change the tab
  const [acivePatientsTab, setacivePatientsTab] = useState("current_tab");

  const handleTabClick = (tab) => {
    setacivePatientsTab(tab);
  };

  // Seacrh Bar filter
  const [currentTabSearchValue, setCurrentTabSearchValue] = useState("");
  const [pastTabSearchValue, setPastTabSearchValue] = useState("");
  const [filteredCurrentPatients, setFilteredCurrentPatients] = useState([]);
  const [filteredPastPatients, setFilteredPastPatients] = useState([]);

  const handleCurrentTabSearchInputChange = (event) => {
    const searchInput = event.target.value.toLowerCase();
    setCurrentTabSearchValue(searchInput);

    if (searchInput.trim() !== "") {
      const filtered = patients.filter((patient) => {
        return patient.customer_name.toLowerCase().includes(searchInput);
      });
      setFilteredCurrentPatients(filtered);
    } else {
      setFilteredCurrentPatients([]);
    }
  };

  const handlePastTabSearchInputChange = (event) => {
    const searchInput = event.target.value.toLowerCase();
    setPastTabSearchValue(searchInput);

    // Filter patients for "Past Patients" tab based on the search input value
    if (searchInput.trim() !== "") {
      const filtered = patientsold.filter((patient) => {
        return patient.customer_name.toLowerCase().includes(searchInput);
      });

      setFilteredPastPatients(filtered);
    } else {
      setFilteredPastPatients([]);
    }
  };

  const handleShowProfile = (index, click_by) => {
    setshowProfile(true);
  };

  return (
    <>
      <div className="container-lg my_patients">
        <div className={showLoader ? "loading" : ""}></div>
        <div>
          <DoctorHeader />
        </div>
      </div>
      <div className="my_patients_dash_container container-sm">
        <div className="row">
          <div
            // className="col-lg-8 _container"
            className={`_container ${showProfile ? "col-lg-8" : "col-lg-12"}`}
          >
            <div className="my_patients_list_container">
              <div className="my_patients_list_head container">
                <div className="current_past_tabs">
                  <div
                    onClick={() => handleTabClick("current_tab")}
                    className={
                      acivePatientsTab === "current_tab"
                        ? "current_tab active_patient_list_tab"
                        : "current_tab"
                    }
                  >
                    <h6>Current Patients</h6>
                  </div>
                  <div
                    onClick={() => handleTabClick("past_tab")}
                    className={
                      acivePatientsTab === "past_tab"
                        ? "past_tab past_patient_list_tab"
                        : "past_tab"
                    }
                  >
                    <h6>Past Patients</h6>
                  </div>
                </div>
                <div className="my_patients_search_bar my-1 my-md-0">
                  {/* <input className='serach_bar' type='text' placeholder='Search...' /> */}
                  {/* For Current tab */}
                  {acivePatientsTab === "current_tab" && (
                    <input
                      className="serach_bar"
                      type="text"
                      placeholder="Search..."
                      value={currentTabSearchValue}
                      onChange={handleCurrentTabSearchInputChange}
                    />
                  )}
                  {/* For Past tab */}
                  {acivePatientsTab === "past_tab" && (
                    <input
                      className="serach_bar "
                      type="text"
                      placeholder="Search..."
                      value={pastTabSearchValue}
                      onChange={handlePastTabSearchInputChange}
                    />  
                  )}
                  <img
                    className="search_bar_icon"
                    src={SearchIcon}
                    alt="icon"
                  />
                </div>
              </div>
            </div>
            <div className="my_patients_list_wrapper container" id="style-1">
              <h3>Patients List</h3>
              <div className="my_patientslist_items">
                {acivePatientsTab === "current_tab" ? (
                  <ul>
                    {currentTabSearchValue.trim() !== "" ? (
                      filteredCurrentPatients.map((item, index) => (
                        <>
                          <li key={index}>
                            <div className="my_patients_item">
                              <div
                                className="my_patients_item_left"
                                onClick={() =>
                                  handlePatientClick(item, index, true)
                                }
                              >
                                <div className="my_patients_item_img">
                                  <img
                                    src={
                                      upcomingAppointImage + item.customer_image
                                    }
                                    alt="Patient"
                                  />
                                </div>
                                <div className="my_patients_item_text ">
                                  <h5>{item.customer_name}</h5>
                                  <p>{item.entry_date}</p>
                                </div>
                              </div>

                              <div className="my_patients_item_right">
                                <span className="green"></span>
                              </div>
                            </div>
                          </li>
                          <hr className="border_top" />
                        </>
                      ))
                    ) : (
                      <>
                        {patients.map((item, index) => (
                          <>
                            <li key={index}>
                              <div className="my_patients_item">
                                <div
                                  className="my_patients_item_left"
                                  onClick={() =>
                                    handlePatientClick(item, index, true)
                                  }
                                >
                                  <div className="my_patients_item_img">
                                    <img
                                      src={
                                        upcomingAppointImage +
                                        item.customer_image
                                      }
                                      alt="Petient"
                                    />
                                  </div>
                                  <div className="my_patients_item_text">
                                    <h5>{item.customer_name}</h5>
                                    <p>{item.entry_date}</p>
                                  </div>
                                </div>
                                <div className="my_patients_item_right">
                                  <span className="green"></span>
                                  {/* {item.status === "Cancelled" ? (
                                      <span
                                        className="btn my_patients_cancel_btn mypatients_cancel_btn_disabled"
                                        disabled
                                      >
                                        Canceled
                                      </span>
                                    ) : (
                                      <span
                                        className="btn my_patients_cancel_btn"
                                        onClick={() => openModal(index)}
                                      >
                                        Cancel
                                      </span>
                                    )}
                                    {item.status === "Cancelled" ? (
                                      <span
                                        className="btn my_patients_call_btn my_patients_call_btn_disabled"
                                        disabled
                                        onClick={() =>
                                          console.log(
                                            `${item.name}'s call clicked`
                                          )
                                        }
                                      >
                                        <span className="my_patients_video_svg">
                                          <img src={VideoCall} alt="icon" />
                                        </span>
                                        Call
                                      </span>
                                    ) : (
                                      <span className="btn my_patients_call_btn">
                                        <span className="my_patients_video_svg">
                                          <img src={VideoCall} alt="icon" />
                                        </span>
                                        Call
                                      </span>
                                    )} */}
                                </div>
                              </div>
                            </li>
                            <hr className="border_top" />
                          </>
                        ))}
                      </>
                    )}
                    {filteredCurrentPatients.length == 0 &&
                    currentTabSearchValue.trim() !== "" ? (
                      <div className=" fs-4 text-center ">No Patient Found</div>
                    ) : (
                      ""
                    )}
                  </ul>
                ) : (
                  <ul>
                    {pastTabSearchValue.trim() !== "" ? (
                      filteredPastPatients.map((item, index) => (
                        <>
                          <li key={index}>
                            <div className="my_patients_item">
                              <div
                                className="my_patients_item_left"
                                onClick={() =>
                                  handlePatientClick(item, index, false)
                                }
                              >
                                <div className="my_patients_item_img">
                                  <img
                                    src={
                                      upcomingAppointImage + item.customer_image
                                    }
                                    alt="Petient"
                                  />
                                </div>
                                <div className="my_patients_item_text">
                                  <h5>{item.customer_name}</h5>
                                  <p>{item.entry_date}</p>
                                </div>
                              </div>
                              <div className="my_patients_item_right">
                                <span className="red"></span>
                              </div>
                            </div>
                          </li>
                          <hr className="border_top" />
                        </>
                      ))
                    ) : (
                      <>
                        {patientsold.map((item, index) => (
                          <>
                            <li key={index}>
                              <div className="my_patients_item">
                                <div
                                  className="my_patients_item_left"
                                  onClick={() =>
                                    handlePatientClick(item, index, false)
                                  }
                                >
                                  <div className="my_patients_item_img">
                                    <img
                                      src={
                                        upcomingAppointImage +
                                        item.customer_image
                                      }
                                      alt="Petient"
                                    />
                                  </div>
                                  <div className="my_patients_item_text">
                                    <h5>{item.customer_name}</h5>
                                    <p>{item.entry_date}</p>
                                  </div>
                                </div>
                                <div className="my_patients_item_right">
                                  <span className="red"></span>
                                </div>
                              </div>
                            </li>
                            <hr className="border_top" />
                          </>
                        ))}
                      </>
                    )}
                    {filteredPastPatients.length == 0 &&
                    pastTabSearchValue.trim() !== "" ? (
                      <div className=" fs-4 text-center ">No Patient Found</div>
                    ) : (
                      ""
                    )}
                  </ul>
                )}
              </div>
            </div>
          </div>

          <div
            className={`_container my_patients_filter_container ${
              showProfile ? "col-lg-4 col-md-6" : "d-none"
            }`}
          >
            {selectedPatient && (
              <div className="my_patients_filter_container">
                <h3>Patient Details</h3>
                <div className="my_patients_filter_wrapper_container">
                  <div className="my_patients_filter_head_main">
                    <div className=" appointment_call_body appointment_call_body2">
                      <div className="appointment_call_body_container appointment_call_body_container2">
                        <div className="appointment_patient_img">
                          <img
                            src={
                              upcomingAppointImage +
                              selectedPatient.customer_image
                            }
                            onError={(e) => {
                              e.target.src = ProfileImgSample; // Provide the path to your fallback image
                            }}
                            alt="Patient"
                          />
                        </div>
                        <h5>{selectedPatient.customer_name}</h5>
                        <div className="appointment_call_time_date appointment_call_time_date_Ptn">
                          <div className="appointment_call_date">
                            <img src={telephone} alt="icon" />
                            <p>{selectedPatient.mobile_no_without_zip}</p>
                          </div>
                          {selectedPatient.customer_email != "" && (
                            <div className="appointment_call_date">
                              <img src={EmailSvg} alt="icon" />
                              <p>{selectedPatient.customer_email}</p>
                            </div>
                          )}

                          <div className="appointment_call_date d-flex flex-wrap">
                            <img
                              style={{ height: "20px", width: "20px" }}
                              src={goalicon}
                              alt="icon"
                            />
                            <p>
                              {customergoal.map((item_select, index) => (
                                <span key={index}>
                                  {index !== 0 && ", "}
                                  <span>{item_select.customer_goal_name}</span>
                                </span>
                              ))}
                            </p>
                          </div>
                        </div>
                        <div className="patient_appointment_call_cancel_btns patient_appointment_call_cancel_btns2">
                          {showdietplan && (
                            <Link
                              to={`/doctor_my_patients_create_diet_plan/${selectedPatient._id}`}
                            >
                              <button
                                className="appointment_call_btn"
                                style={{ whiteSpace: "nowrap" }}
                              >
                                Create Diet Plan
                              </button>
                            </Link>
                          )}

                          <Link
                            to={`/doctor_my_patients_show_diet_plan/${selectedPatient._id}`}
                          >
                            <button
                              className="appointment_call_btn"
                              style={{ whiteSpace: "nowrap" }}
                            >
                              See Diet Plan
                            </button>
                          </Link>
                          <Link to={`/MoreDetail/${selectedPatient._id}`}>
                            <button
                              className="appointment_cancel_btn"
                              style={{ whiteSpace: "nowrap" }}
                              data-toggle="modal"
                              data-target=".bd-example-modal-lg"
                            >
                              More Details
                            </button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        {/* Details PopUp modal */}
      </div>
    </>
  );
}

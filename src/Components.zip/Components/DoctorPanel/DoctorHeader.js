import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import "../../Css/Header.css";
import "../../Css/loading.css";
import StopWatch from "../../Assests/images/stopwatch_svg.svg";
import HomeSvgActive from "../../Assests/images/home_svg.svg";
import HomeSvg from "../../Assests/images/home_black.svg";
import FeedSvg from "../../Assests/images/feed_svg.svg";
import UsersSvg from "../../Assests/images/users_svg.svg";
import ChatSvg from "../../Assests/images/chat_svg.svg";
import ChatSvgActive from "../../Assests/images/chats_active.svg";
import ProfileSvg from "../../Assests/images/profile_svg.svg";
import CalendarSvg from "../../Assests/images/calendar_svg.svg";
import CalendarSvgActive from "../../Assests/images/calender_active.svg";
import FeedSvgActive from "../../Assests/images/feeds_active.svg";
import UsersSvgActive from "../../Assests/images/my_patients_active.svg";
import ProfileSvgActive from "../../Assests/images/my_profile_active.svg";
import ProfileImgSample from "../../Assests/images/profile_sample.jpg";
import { useNavigate } from "react-router-dom";
import { retrieveData } from "../../LocalConnection/LocalConnection.js";
import {
  server_post_data,
  get_last_appointment,
} from "../../ServiceConnection/serviceconnection.js";
function DoctorHeader() {
  const location = useLocation();
  const navigate = useNavigate();
  const [retriveDoctorName, setRetriveDoctorName] = useState("");
  const [retriveDoctorProfession, setRetriveDoctorProfession] = useState("");
  const [retriveDoctorImage, setRetriveDoctorImage] = useState("");
  const [countdown, setCountdown] = useState("");
  let countdownInterval = 100;
  useEffect(() => {
    const retrievedDoctorName = retrieveData("doctor_name");
    const retrievedDoctorProfession = retrieveData("doctor_profession");
    const retrievedDoctorImage = retrieveData("doctor_image");
    const retrievedDoctorId = retrieveData("doctor_id");
    setRetriveDoctorName(retrievedDoctorName);
    setRetriveDoctorProfession(retrievedDoctorProfession);
    setRetriveDoctorImage(retrievedDoctorImage);

    const retrievedDataFind = retrieveData("doctor_email");
    if (retrievedDataFind === "null" || retrievedDataFind === null) {
      navigate("/login");
    }
    master_data_get(retrievedDoctorId);
  }, [navigate]);

  const master_data_get = async (retrievedDoctorId) => {
    const fd = new FormData();
    fd.append("doctor_id", retrievedDoctorId);
    await server_post_data(get_last_appointment, fd)
      .then((Response) => {
        if (Response.data.error) {
          alert(Response.data.message);
        } else {
          if (Response.data.message.data_appointment.length > 0) {
            countdownTimer(
              Response.data.message.data_appointment[0].booking_date +
                "T" +
                Response.data.message.data_appointment[0].booking_start_time +
                ":00"
            );
          }
        }
      })
      .catch((error) => {
        //err
      });
  };

  const checkUrl = (urlSegment, check_url) => {
    const parts = urlSegment.split("/");

    const action = parts[1]; // "doctor_my_patients_create_diet_plan"
    if (action === check_url) {
      return true;
    }
    return false;
  };

  function countdownTimer(targetDateTime) {
    const targetTime = new Date(targetDateTime).getTime();

    const updateCountdown = () => {
      const currentTime = new Date().getTime();
      const timeDifference = targetTime - currentTime;

      if (timeDifference <= 0) {
        clearInterval(countdownInterval);
        setCountdown(null);
      } else {
        const seconds = Math.floor(timeDifference / 1000) % 60;
        const minutes = Math.floor((timeDifference / 1000 / 60) % 60);
        const hours = Math.floor((timeDifference / 1000 / 60 / 60) % 24);
        const days = Math.floor(timeDifference / 1000 / 60 / 60 / 24);

        let show_data = "";

        if (days > 0) {
          show_data = show_data + `${days}D `;
        }
        if (hours > 0) {
          show_data = show_data + `${hours}H `;
        }
        if (minutes > 0) {
          show_data = show_data + `${minutes}M `;
        }
        if (seconds > 0) {
          show_data = show_data + `${seconds}S `;
        }
        setCountdown(show_data);
      }
    };

    updateCountdown(); // Call the function immediately to avoid initial delay

    countdownInterval = setInterval(updateCountdown, 1000); // Update every second
  }

  return (
    <div className="header">
      <div className="header_wrapper">
        <div className="header_container d-flex justify-content-between flex-wrap">
          <div className="img_name_div d-flex align-items-center">
            <div className="img_div">
              <img
                src={retriveDoctorImage}
                alt="Nutritionist"
                onError={(e) => {
                  e.target.src = ProfileImgSample; // Provide the path to your fallback image
                }}
              />
            </div>
            <div className="name_div">
              <h5 className="m-0">{retriveDoctorName}</h5>
              <p className="m-0">{retriveDoctorProfession}</p>
            </div>
          </div>
          {countdown ? (
            <div className="time_appointment_div d-flex align-items-center">
              <div className="time_div text-center">
                <p className="m-0 font-weight-bold text-black">
                  Next Appointment In
                </p>
                <div>
                  <img src={StopWatch} alt="StopWatch" />
                  <span className="text-black">
                    <span className="time_span">&nbsp;{countdown}</span>
                  </span>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        <div className="menu_bar">
          <div className="menu_bar_wrapper">
            <div className="menu_bar_container d-flex justify-content-around">
              <Link to="/doctorwelcomepage">
                <div
                  className={`card text-center ${
                    location.pathname === "/doctorwelcomepage"
                      ? "active_menu"
                      : ""
                  }`}
                >
                  <div className="card-body px-1 py-4 ">
                    {location.pathname === "/doctorwelcomepage" ? (
                      <img src={HomeSvgActive} alt="icon" />
                    ) : (
                      <img src={HomeSvg} alt="icon" />
                    )}
                    <p className="card-text">Home</p>
                  </div>
                </div>
              </Link>

              <Link to="/doctor_my_calendar">
                <div
                  className={`card text-center ${
                    location.pathname === "/doctor_my_calendar"
                      ? "active_menu"
                      : ""
                  }`}
                >
                  <div className="card-body px-1 py-4">
                    {location.pathname === "/doctor_my_calendar" ? (
                      <img src={CalendarSvgActive} alt="icon" />
                    ) : (
                      <img src={CalendarSvg} alt="icon" />
                    )}
                    <p className="card-text">Calendar</p>
                  </div>
                </div>
              </Link>

              <Link to="/doctor_feeds_and_post">
                <div
                  className={`card text-center ${
                    location.pathname === "/doctor_feeds_and_post"
                      ? "active_menu"
                      : ""
                  }`}
                >
                  <div className="card-body px-1 py-4">
                    {location.pathname === "/doctor_feeds_and_post" ? (
                      <img src={FeedSvgActive} alt="icon" />
                    ) : (
                      <img src={FeedSvg} alt="icon" />
                    )}
                    <p className="card-text">Feeds</p>
                  </div>
                </div>
              </Link>

              <Link to="/doctor_patients">
                <div
                  className={`card text-center ${
                    checkUrl(location.pathname, "doctor_patients") ||
                    checkUrl(
                      location.pathname,
                      "doctor_my_patients_create_diet_plan"
                    ) ||
                    checkUrl(
                      location.pathname,
                      "doctor_my_patients_show_diet_plan"
                    ) ||
                    checkUrl(location.pathname, "MoreDetail")
                      ? "active_menu"
                      : ""
                  }`}
                >
                  <div className="card-body px-1 py-4">
                    {checkUrl(location.pathname, "doctor_patients") ||
                    checkUrl(
                      location.pathname,
                      "doctor_my_patients_create_diet_plan"
                    ) ||
                    checkUrl(
                      location.pathname,
                      "doctor_my_patients_show_diet_plan"
                    ) ||
                    checkUrl(location.pathname, "MoreDetail") ? (
                      <img src={UsersSvgActive} alt="icon" />
                    ) : (
                      <img src={UsersSvg} alt="icon" />
                    )}
                    <p className="card-text">My Patients</p>
                  </div>
                </div>
              </Link>

              <Link to="/doctor_chats">
                <div
                  className={`card text-center ${
                    location.pathname === "/doctor_chats" ? "active_menu" : ""
                  }`}
                >
                  <div className="card-body px-1 py-4">
                    {location.pathname === "/doctor_chats" ? (
                      <img src={ChatSvgActive} alt="icon" />
                    ) : (
                      <img src={ChatSvg} alt="icon" />
                    )}
                    <p className="card-text">Chats</p>
                  </div>
                </div>
              </Link>

              <Link to="/doctor_admin_general_profile">
                <div
                  className={`card text-center d-flex align-items-end ${
                    location.pathname === "/doctor_admin_general_profile"
                      ? "active_menu"
                      : ""
                  }`}
                >
                  <div className="card-body px-1 py-4">
                    {location.pathname === "/doctor_admin_general_profile" ? (
                      <img src={ProfileSvgActive} alt="icon" />
                    ) : (
                      <img src={ProfileSvg} alt="icon" />
                    )}
                    <p className="card-text">My Profile</p>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DoctorHeader;

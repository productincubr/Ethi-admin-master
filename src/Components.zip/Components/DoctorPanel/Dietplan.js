import imag from "./assets/ethi-logo.png";
import sup from "./assets/supliment.png";

const Dieplan = () => {
  return (
    <div className="container " id="pdfContent">
      <div className="container-1 " id="pdfContent-1">
        <div className="div">
          <div className="div-2">
            <div className="div-3">
              <div className="div-4">
                <div className="div-5">
                  <div className="div-6">
                    <div className="div-7">“</div>
                    <div className="div-8">
                      <img src={imag} />
                      <div className="div-9">Every Thing Health Inspired</div>
                    </div>
                  </div>
                  <div className="div-10" />
                </div>
                <div className="div-11">
                  <div className="div-12">
                    <div className="div-13">Nivesh bhalla</div>
                    <div className="div-14"> 03/10/2023</div>
                  </div>
                </div>
              </div>
              <div className="div-15" />
              <div className="div-16" />
            </div>
          </div>
        </div>
      </div>
      <div className="container-2" id="pdfContent-2">
        <div className="div-17">
          <div className="div-18">
            <div className="div-19">
              <div className="div-20"></div>
            </div>
            <div className="div-21">Diet Plan</div>
            <div className="div-22"></div>
          </div>
          <div className="div-23">
            <div className="div-24">
              <div className="div-25">On Waking Up</div>
              <div className="div-26">
                1 cup jeera water, 1 tsp. boiled
                <br />5 soaked almonds
              </div>
            </div>
            <div className="div-27">
              <div className="div-28">Breakfast</div>
              <div className="div-29">
                1 katori sprouts + sabzi + 1roti(1/2 wheat+1/2 amarnath)
              </div>
            </div>
            <div className="div-30">
              <div className="div-31">12:30 PM</div>
              <div className="div-32">
                1 Katori dal/chana/rajma + sabzi + 1 roti(1/2 wheat + 1/2
                amarnath)
              </div>
            </div>
            <div className="div-33">
              <div className="div-34">04:00 PM</div>
              <div className="div-35">1 Bowl anaar</div>
            </div>
            <div className="div-36">
              <div className="div-37">06:00 PM</div>
              <div className="div-38">1 cup water + 1 scoop Nack</div>
            </div>
            <div className="div-39">
              <div className="div-40">Breakfast</div>
              <div className="div-41">
                100g tofu + 1 avacado toast + veggies or
                <br />
                1 bowl sabzi + 1 dal cheela or
                <br />
                1 bowl ver red lentil pasta = avacado or
                <br />1 bowl veg quinoa + avacado
              </div>
            </div>
            <div className="div-42">
              <div className="div-43">Bedtime</div>
              <div className="div-44">1 tsp. triphala + warm water</div>
            </div>
          </div>
          <div className="div-45"></div>
          <div className="div-46"></div>
        </div>
      </div>
      <div className="container-3" id="pdfContent-3">
        <div class="div-47">
          <div class="div-48">
            <div class="div-49">
              <div class="div-50"></div>
              <img src={sup} />
            </div>
            <div class="div-51">
              <div class="div-52">lorem ipsum</div>
              <div class="div-53"></div>
            </div>
          </div>
          <div class="div-54">
            <div class="div-55">
              <div class="div-56">Points to Remember</div>
              <div class="div-57">Water : 3 ltrs/Day</div>
              <div class="div-58">
                Veggies are free food except potato, peas & corn
              </div>
              <div class="div-59">
                Oils : Cow milk ghee, coconut oil, peanut & <br /> mustard oil
              </div>
              <div class="div-60">Raw Sugar/Honey/Jaggery max 2 tsp/day</div>
              <div class="div-61">Max 2 decafs a day</div>
              <div class="div-62">No Tea</div>
            </div>
            <div class="div-63"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dieplan;

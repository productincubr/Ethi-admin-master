import React, { useState } from "react";
import {
  medicalConditions,
  symptoms,
  diseases,
  bloodGroup,
  foodPre,
  cuisines,
  cravings,
  radioOptionTitle,
  triggers,
  hungryTime,
  activityOptionTitle,
  stressLevel,
} from "../../CommonJquery/Commondata.js";
import {
  check_vaild_save,
  combiled_form_data,
  handleIaphabetnumberdotChange,
  handleNumbersChange,
} from "../../CommonJquery/CommonJquery.js";
import {
  assesment_form_patients_save,
  server_post_data,
} from "../../ServiceConnection/serviceconnection.js";
function DoctorpatientsForm(customer_id, doctor_id, subscription_id) {
  const [selectedNumber, setSelectedNumber] = useState(null);
  const [showLoader, setShowLoader] = useState(false);
  const handleNumberClick = (number) => {
    setSelectedNumber(number);
  };

  const handleReloadClick = () => {
    window.location.reload(); // Reload the page when the button is clicked
  };

  const handleSaveChangesdynamic = async (form_data, url_for_save) => {
    let vaild_data = check_vaild_save(form_data);
    if (vaild_data) {
      setShowLoader(true);
      let fd_from = combiled_form_data(form_data, null);
      fd_from.append("doctor_id", customer_id.doctor_id);
      fd_from.append("customer_id", customer_id.customer_id);
      fd_from.append("subscription_id", customer_id.subscription_id);
      fd_from.append("stress_level", selectedNumber);
      await server_post_data(url_for_save, fd_from)
        .then((Response) => {
          setShowLoader(false);
          if (Response.data.error) {
            alert(Response.data.message);
          } else {
            const closeButton = document.querySelector(
              "#" + form_data + ' [data-dismiss="modal"]'
            );
            handleReloadClick();
            if (closeButton) {
              closeButton.click();
            }
          }
        })
        .catch((error) => {
          setShowLoader(false);
        });
    }
  };

  function handleNumbersChange1(event) {
    // Get the input value
    const inputValue = event.target.value;
  
    // Check if the input is a valid number
    const age = parseInt(inputValue);
  
    // Check if the age is greater than 125
    if (age > 125) {
      // If greater than 125, set the input value to 125
      event.target.value = '125';
    }
  }

  const handleNumbersChange = (e) => {
    // Get the entered value as a number
    const enteredValue = parseInt(e.target.value, 10);

    // Check if the entered value is greater than 300
    if (enteredValue > 300) {
      // If it is, set the value to 300
      e.target.value = '300';
    }
    // You can add further logic or state updates if needed
  };
  
  return (
    <div className="modal-content">
      <div className={showLoader ? "loading" : ""}></div>
      <form id="form_patinents_form">
        <div className="modal-header form_popup_header">
          <button
            type="button"
            className="close"
            data-dismiss="modal"
            aria-label="Close"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div className="modal-body p-5 pb-0">
          <h3 className="modal-title" id="exampleModalLabel">
            Assesment form
          </h3>
          <div className="circleDiv">
            <p>Health Goals</p>
            <div className="circleDot" />
            <p>Lifestyle</p>
            <div className="circleDot" />
            <p>Eating Habits</p>
          </div>
          <div className="my-5">
            <div>
              <h4>Q1 Medical condition</h4>

              <h5>Select all Medical condition you are facing</h5>

              <div className="inputSymptoms row">
                {medicalConditions.map((item, index) => (
                  <div className="col-md-4 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`medCondition${index}`}
                      name="medCondition[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="item1">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="my-5">
              <h4>Q2 Signs & symptoms</h4>

              <h5>
                Select all signs and symptoms you are facing in day to day Life
              </h5>

              <div className="inputSymptoms row">
                {symptoms.map((item, index) => (
                  <div className="col-md-4 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`signs${index}`}
                      name="signs[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="signs">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q3 Age</h4>
              <div className="textareaBox" style={{ width: "fit-content" }}>
                <div className="d-flex">
                  <div className="heightOption">
                    <label>
                      {" "}
                      <p>Mention your age</p>
                    </label>{" "}
                    <br />
                    <input
                      className="trio_mendate height_input"
                      id="ageNum"
                      name="ageNum"
                      type="text"
                      maxLength={3}
                      onInput={handleNumbersChange}
                      onChange={handleNumbersChange1}
                    ></input>
                  </div>
                </div>
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q4 Medications</h4>
              <div className="textareaBox">
                <p>Mention all medicines taken by you</p>
                <textarea
                  className="trio_mendate"
                  id="medicines"
                  name="medicines"
                  placeholder="Type your answer here"
                  maxLength={200}
                  onInput={handleIaphabetnumberdotChange}
                />
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q5 Supplements</h4>
              <div className="textareaBox">
                <p>Mention all supplements taken by you</p>
                <textarea
                  className="trio_mendate"
                  id="supplements"
                  name="supplements"
                  placeholder="Type your answer here"
                  maxLength={200}
                  onInput={handleIaphabetnumberdotChange}
                />
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q6 Food allergy/ intolerance</h4>
              <div className="textareaBox">
                <p>Mention all allergy/intolerance you have</p>
                <textarea
                  className="trio_mendate"
                  id="allergy"
                  name="allergy"
                  placeholder="Type your answer here"
                  maxLength={200}
                  onInput={handleIaphabetnumberdotChange}
                />
              </div>
            </div>

            <div className="diseasesBox">
              <h4 className="mt-5 mb-3">Q7 Diseases</h4>

              <h5>Select all diseases</h5>

              <div className="inputSymptoms row">
                {diseases.map((item, index) => (
                  <div className="col-md-6 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`diseases${index}`}
                      name="diseases[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="item1">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="bloodGroup">
              <h4 className="mt-5 mb-3">Q8 Blood Group</h4>

              <h5>Select Your Blood Group</h5>

              <div className="inputSymptoms row">
                {bloodGroup.map((item, index) => (
                  <div key={index} className="col-md-3 d-flex foodFrequencyList">
                    <div className=""><input
                      type="radio"
                      id={`bloodGroup${index}`}
                      name="bloodGroup"
                      className="trio_mendate "
                      value={item.value}
                    /></div>
                    <div><label>{item.name}</label></div>
                  </div>
                ))}
              </div>
            </div>

            <div className="heightBox">
              <h4 className="mt-5 mb-3">Q9 Height & Weight</h4>

              <h5>Enter Your Height and Weight here</h5>

              <div className="d-flex">
                <div className="d-flex">
                  <div className="heightOption">
                    <label>CM</label> <br />
                    <input
                      className="trio_mendate height_input"
                      type="text"
                      id="hignt_number"
                      name="hignt_number"
                      maxLength={3}
                      onInput={handleNumbersChange}
                    ></input>
                  </div>
                </div>
                <div className="d-flex">
                  <div className="heightOption">
                    <label>Weight</label> <br />
                    <input
                      className="trio_mendate height_input"
                      type="text"
                      id="weight_number"
                      name="weight_number"
                      maxLength={3}
                      onInput={handleNumbersChange}
                    ></input>
                  </div>
                </div>
              </div>
            </div>

            <div className="foodPre">
              <h4 className="mt-5 mb-3">Q10 Food Preference</h4>

              <h5>Select your food preference</h5>

              <div className="inputSymptoms row ">
                {foodPre.map((item, index) => (
                  <div key={index} className="col-md-3 d-flex foodFrequencyList">
                    <div><input
                      type="radio"
                      id={`foodPre${index}`}
                      name="foodPre"
                      className="trio_mendate"
                      value={item.value}
                    /></div>
                    <div> <label>{item.name}</label></div>
                   
                  </div>
                ))}
              </div>
            </div>

            <div className="cuisines">
              <h4 className="mt-5 mb-3">Q11 Cuisines You Enjoy</h4>

              <h5>Select all cuisines you enjoy</h5>

              <div className="inputSymptoms row">
                {cuisines.map((item, index) => (
                  <div className="col-md-6 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`cuisines${index}`}
                      name="cuisines[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="cuisines">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="cravings">
              <h4 className="mt-5 mb-3">Q12 Food Cravings</h4>

              <h5>What kind of food you crave for</h5>

              <div className="inputSymptoms row">
                {cravings.map((item, index) => (
                  <div className="col-md-6 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`cravings${index}`}
                      name="cravings[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="cravings">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="foodFrequency">
              <h4 className="mt-5 mb-3">Q13 Food Frequency</h4>
              <h5>How many times do you consume these items ?</h5>
              {radioOptionTitle.map((item, index) => (
                <div key={index} className="foodFrequencyList">
                  <h6 className="my-3">{item.title}</h6>
                  <div className="row">
                    {[
                      "Daily",
                      "2-3 Times a week",
                      "2-3 Times a month",
                      "Never",
                    ].map((option, optionIndex) => (
                      <div key={optionIndex} className="col-md-3">
                        <input
                          type="radio"
                          id={`foodTimes${index}`}
                          name={`foodTimes${index}`}
                          value={option}
                        />
                        <label>{option}</label>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="triggers">
              <h4 className="mt-5 mb-3">Q14 What triggers you to eat ?</h4>

              <h5>Select all triggers you to eat</h5>

              <div className="inputSymptoms row">
                {triggers.map((item, index) => (
                  <div className="col-md-6 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`triggers${index}`}
                      name="triggers[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="triggers">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q15 Eating habits you are proud of</h4>
              <div className="textareaBox">
                <p>Mention Those eating habits that make you feel good</p>
                <textarea
                  id="eatHabits"
                  name="eatHabits"
                  className="trio_mendate"
                  placeholder="Type your answer here"
                  maxLength={200}
                  onInput={handleIaphabetnumberdotChange}
                />
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q16 Sleep Time</h4>
              <div className="timeBox">
                <div className="d-flex">
                  <div className="timeOptions">
                    <label>Sleep Time</label> <br />
                    <input
                      className="trio_mendate"
                      id="sleepTime"
                      name="sleepTime"
                      type="time"
                    />
                  </div>
                  <div className="timeOptions">
                    <label>Wake up Time</label> <br />
                    <input
                      className="trio_mendate"
                      id="wakeTime"
                      name="wakeTime"
                      type="time"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="triggers">
              <h4 className="mt-5 mb-3">Q17 Most Hungry</h4>

              <h5>When you are most hungry ?</h5>

              <div className="inputSymptoms row">
                {hungryTime.map((item, index) => (
                  <div className="col-md-6 col-xs-6 my-1" key={index}>
                    <input
                      type="checkbox"
                      id={`hungry${index}`}
                      name="hungry[]"
                      value={item.value}
                      className="trio_mendate"
                    />
                    <label htmlFor="hungry">{item.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="stressLevel">
              <h4 className="mt-5 mb-3">Q18 Stress Level</h4>

              <h5>Rate your stress level</h5>

              <div className="stressLevelBox">
                <p className="rangeStress">Low</p>
                <div className="d-flex">
                  {stressLevel.map((item, index) => (
                    <p
                      className={`numberBox ${
                        selectedNumber >= index + 1 ? "selected" : ""
                      }`}
                      key={index}
                      onClick={() => handleNumberClick(index + 1)}
                    >
                      {item.input}
                    </p>
                  ))}
                </div>
                <p className="rangeStress">High</p>
              </div>
            </div>

            <div className="foodFrequency">
              <h4 className="mt-5 mb-3">Q19 Water Consumption</h4>
              <h5>How much water do you consume on a day ?</h5>
              <div className="foodFrequencyList">
                <div className="row">
                  <div className="col-md-3">
                    <input
                      type="radio"
                      className="trio_mendate"
                      id="waterOp"
                      name="waterOp"
                      value="1-2L"
                    />
                    <label>1-2L</label>
                  </div>
                  <div className="col-md-3">
                    <input
                      type="radio"
                      className="trio_mendate"
                      id="waterOp"
                      name="waterOp"
                      value="2-3L"
                    />
                    <label>2-3L</label>
                  </div>
                  <div className="col-md-3">
                    <input
                      type="radio"
                      className="trio_mendate"
                      id="waterOp"
                      name="waterOp"
                      value="3-4L"
                    />
                    <label>3-4L</label>
                  </div>
                </div>
              </div>
            </div>

            <div className="foodFrequency">
              <h4 className="mt-5 mb-3">Q20 Smoking</h4>
              <h5>Do you smoke ?</h5>
              <div className="foodFrequencyList">
                <div className="row">
                  <div className="col-md-6">
                    <input
                      type="radio"
                      className="trio_mendate"
                      id="smokeOp"
                      name="smokeOp"
                      value="No"
                    />
                    <label>No</label>
                  </div>
                  <div className="col-md-6">
                    <input
                      type="radio"
                      className="trio_mendate"
                      id="smokeOp"
                      name="smokeOp"
                      value="Yes"
                    />
                    <label>Yes</label>
                  </div>
                </div>
              </div>
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Q21 Menstrual cycle</h4>
              <div className="textareaBox">
                <p>Periods (Regular/How long/Painful)</p>
                <textarea
                  className="trio_mendate"
                  id="menstrual"
                  name="menstrual"
                  placeholder="Type your answer here"
                  maxLength={200}
                  onInput={handleIaphabetnumberdotChange}
                />
              </div>
            </div>

            <div className="foodFrequency">
              <h4 className="mt-5 mb-3">Q22 Activity</h4>
              <h5>How much of the following activity you perform ?</h5>
              {activityOptionTitle.map((item, index) => (
                <div key={index} className="foodFrequencyList">
                  <h6 className="my-3">{item.title}</h6>
                  <div className="row">
                    {[
                      "Daily",
                      "2-3 Times a week",
                      "2-3 Times a month",
                      "Never",
                    ].map((option, optionIndex) => (
                      <div key={optionIndex} className="col-md-3">
                        <input
                          className="trio_mendate"
                          id={`activity${index}`}
                          type="radio"
                          name={`activity${index}`}
                          value={option}
                        />
                        <label>{option}</label>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="textBox">
              <h4 className="mt-5 mb-3">Other</h4>
              <div className="textareaBox">
                <p>Any other activity of you perform</p>
                <textarea
                  className="trio_mendate"
                  id="otherSup"
                  name="otherSup"
                  placeholder="Type your answer here"
                />
              </div>
            </div>

            

            <div className="foodFrequency">
              <h4 className="mt-5 mb-3">Q23 Motivation Needed</h4>
            
                <h6>Motivation needed to start your fitness journey</h6>
                
                <div className="foodFrequencyList my-5">
              <div className="row">
                <div className="col-md-3">
                  <input
                    type="radio"
                    className="trio_mendate"
                    id="otherOp"
                    name="otherOp"
                    value="Daily"
                  />
                  <label>Daily</label>
                </div>
                <div className="col-md-3">
                  <input
                    type="radio"
                    className="trio_mendate"
                    id="otherOp"
                    name="otherOp"
                    value="1 Time a week"
                  />
                  <label>1 Time a week</label>
                </div>
                <div className="col-md-3">
                  <input
                    type="radio"
                    className="trio_mendate"
                    id="otherOp"
                    name="otherOp"
                    value="2-3 Times a week"
                  />
                  <label>2-3 Times a week</label>
                </div>
              </div>
            </div>
            </div>

            {/* Ends Here */}
          </div>
        </div>
        <div className="modal-footer modal_foot_form">
          <button
            type="button"
            className="btn btn-secondary"
            data-dismiss="modal"
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() =>
              handleSaveChangesdynamic(
                "form_patinents_form",
                assesment_form_patients_save
              )
            }
          >
            Save
          </button>
        </div>
      </form>
    </div>
  );
}

export default DoctorpatientsForm;
